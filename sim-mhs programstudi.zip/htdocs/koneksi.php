<?php
// koneksi.php — koneksi database MySQL (InfinityFree)
// Ganti 4 nilai di bawah sesuai panel InfinityFree: MySQL Databases
$db_host = "sql105.infinityfree.com";
$db_user = "if0_43241440";
$db_pass = "prot1btT1w5R";
$db_name = "if0_43241440_simmhs";

//$db_host = "sqlXXX.infinityfree.com";   // MySQL Hostname
//$db_user = "if0_XXXXXXXX";              // MySQL Username
//$db_pass = "PASSWORD_AKUN_HOSTING";     // Password akun hosting (vPanel)
//$db_name = "if0_XXXXXXXX_simmhs";       // Nama database

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
