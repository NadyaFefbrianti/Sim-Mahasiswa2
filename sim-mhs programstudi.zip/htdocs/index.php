<?php
require "koneksi.php";

// Ringkasan jumlah mahasiswa per prodi untuk landing page
$prodi = [];
$res = mysqli_query($conn, "SELECT p.kode, p.nama, COUNT(m.id) AS jumlah
                            FROM prodi p LEFT JOIN mahasiswa m ON m.prodi_id = p.id
                            GROUP BY p.id ORDER BY p.nama");
if ($res) while ($r = mysqli_fetch_assoc($res)) $prodi[] = $r;
$login = isset($_SESSION["user"]);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SIM Mahasiswa per Program Studi</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="landing">
  <header class="topbar">
    <a class="brand" href="index.php">SIM Mahasiswa</a>
    <nav>
      <a href="#prodi">Program studi</a>
      <a href="#fitur">Fitur</a>
      <a class="btn btn-primary" href="<?= $login ? "dashboard.php" : "login.php" ?>"><?= $login ? "Buka dashboard" : "Masuk" ?></a>
    </nav>
  </header>

  <section class="hero">
    <div class="hero-text">
      <h1>Data mahasiswa, tertata per program studi.</h1>
      <p>Admin akademik melihat jumlah mahasiswa tiap prodi, mencari berdasarkan nama atau NIM, dan memperbarui data dari satu halaman.</p>
      <a class="btn btn-primary btn-lg" href="<?= $login ? "dashboard.php" : "login.php" ?>">Kelola data mahasiswa</a>
    </div>
    <div class="hero-board" aria-label="Jumlah mahasiswa per program studi">
      <?php foreach ($prodi as $p): ?>
        <div class="board-row">
          <span class="kode"><?= htmlspecialchars($p["kode"]) ?></span>
          <span class="nm"><?= htmlspecialchars($p["nama"]) ?></span>
          <strong><?= (int)$p["jumlah"] ?></strong>
        </div>
      <?php endforeach; ?>
      <?php if (!$prodi): ?><p class="muted">Data prodi belum tersedia.</p><?php endif; ?>
    </div>
  </section>

  <section id="prodi" class="section">
    <h2>Program studi terdaftar</h2>
    <div class="cards">
      <?php foreach ($prodi as $p): ?>
        <article class="card">
          <h3><?= htmlspecialchars($p["nama"]) ?></h3>
          <p><?= (int)$p["jumlah"] ?> mahasiswa terdaftar</p>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

  <section id="fitur" class="section section-alt">
    <h2>Yang bisa dilakukan admin</h2>
    <ul class="features">
      <li><strong>Filter per prodi.</strong> Klik kartu prodi di dashboard untuk melihat mahasiswanya saja.</li>
      <li><strong>Cari cepat.</strong> Temukan mahasiswa lewat nama atau NIM.</li>
      <li><strong>Tambah dan hapus data.</strong> Perubahan langsung tampil di tabel.</li>
      <li><strong>Akses terbatas.</strong> Dashboard hanya terbuka setelah masuk dengan akun admin.</li>
    </ul>
  </section>

  <footer class="footer">
    <p>SIM Mahasiswa — Tugas Praktikum Pertemuan 2 · [Nama kamu] · [NIM kamu]</p>
  </footer>
</body>
</html>
