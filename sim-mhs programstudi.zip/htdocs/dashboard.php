<?php
require "koneksi.php";

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}
if (empty($_SESSION["csrf"])) {
    $_SESSION["csrf"] = bin2hex(random_bytes(16));
}

$pesan = ""; $tipe = "ok";

// ---- Tambah / hapus mahasiswa ----
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")) {
        die("Permintaan tidak valid.");
    }
    $aksi = $_POST["aksi"] ?? "";

    if ($aksi === "tambah") {
        $nim = trim($_POST["nim"] ?? "");
        $nama = trim($_POST["nama"] ?? "");
        $prodi_id = (int)($_POST["prodi_id"] ?? 0);
        $angkatan = (int)($_POST["angkatan"] ?? 0);
        $email = trim($_POST["email"] ?? "");

        if ($nim === "" || $nama === "" || !$prodi_id || !$angkatan) {
            $pesan = "NIM, nama, program studi, dan angkatan wajib diisi."; $tipe = "err";
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO mahasiswa (nim, nama, prodi_id, angkatan, email) VALUES (?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, "ssiis", $nim, $nama, $prodi_id, $angkatan, $email);
            if (mysqli_stmt_execute($stmt)) {
                $pesan = "Mahasiswa $nama ditambahkan.";
            } else {
                $pesan = "NIM $nim sudah terdaftar."; $tipe = "err";
            }
        }
    } elseif ($aksi === "hapus") {
        $id = (int)($_POST["id"] ?? 0);
        $stmt = mysqli_prepare($conn, "DELETE FROM mahasiswa WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $pesan = "Data mahasiswa dihapus.";
    }
}

// ---- Data prodi + jumlah mahasiswa ----
$prodi = [];
$res = mysqli_query($conn, "SELECT p.id, p.kode, p.nama, COUNT(m.id) AS jumlah
                            FROM prodi p LEFT JOIN mahasiswa m ON m.prodi_id = p.id
                            GROUP BY p.id ORDER BY p.nama");
while ($r = mysqli_fetch_assoc($res)) $prodi[] = $r;
$total = array_sum(array_column($prodi, "jumlah"));

// ---- Filter & pencarian ----
$f_prodi = (int)($_GET["prodi"] ?? 0);
$q = trim($_GET["q"] ?? "");

$sql = "SELECT m.id, m.nim, m.nama, m.angkatan, m.email, p.nama AS prodi
        FROM mahasiswa m JOIN prodi p ON p.id = m.prodi_id WHERE 1=1";
$types = ""; $params = [];
if ($f_prodi) { $sql .= " AND m.prodi_id = ?"; $types .= "i"; $params[] = $f_prodi; }
if ($q !== "") { $sql .= " AND (m.nama LIKE ? OR m.nim LIKE ?)"; $types .= "ss"; $params[] = "%$q%"; $params[] = "%$q%"; }
$sql .= " ORDER BY p.nama, m.nim";

$stmt = mysqli_prepare($conn, $sql);
if ($types) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$mhs = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard — SIM Mahasiswa</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="app">
  <header class="topbar">
    <a class="brand" href="index.php">SIM Mahasiswa</a>
    <div class="topbar-right">
      <span><?= e($_SESSION["user"]["nama"]) ?></span>
      <a class="btn btn-ghost" href="logout.php">Keluar</a>
    </div>
  </header>

  <main class="wrap">
    <h1>Mahasiswa per program studi</h1>

    <?php if ($pesan): ?>
      <div class="alert <?= $tipe === "ok" ? "alert-ok" : "" ?>"><?= e($pesan) ?></div>
    <?php endif; ?>

    <section class="stats">
      <a class="stat <?= !$f_prodi ? "active" : "" ?>" href="dashboard.php">
        <strong><?= $total ?></strong><span>Semua prodi</span>
      </a>
      <?php foreach ($prodi as $p): ?>
        <a class="stat <?= $f_prodi === (int)$p["id"] ? "active" : "" ?>" href="dashboard.php?prodi=<?= $p["id"] ?>">
          <strong><?= $p["jumlah"] ?></strong><span><?= e($p["nama"]) ?></span>
        </a>
      <?php endforeach; ?>
    </section>

    <section class="panel">
      <form method="get" class="search">
        <select name="prodi" aria-label="Filter program studi">
          <option value="0">Semua program studi</option>
          <?php foreach ($prodi as $p): ?>
            <option value="<?= $p["id"] ?>" <?= $f_prodi === (int)$p["id"] ? "selected" : "" ?>><?= e($p["nama"]) ?></option>
          <?php endforeach; ?>
        </select>
        <input type="search" name="q" placeholder="Cari nama atau NIM" value="<?= e($q) ?>">
        <button class="btn btn-primary" type="submit">Cari</button>
      </form>

      <div class="table-scroll">
        <table>
          <thead>
            <tr><th>NIM</th><th>Nama</th><th>Program studi</th><th>Angkatan</th><th>Email</th><th></th></tr>
          </thead>
          <tbody>
          <?php if (!$mhs): ?>
            <tr><td colspan="6" class="empty">Belum ada data yang cocok. Tambahkan mahasiswa lewat formulir di bawah.</td></tr>
          <?php endif; ?>
          <?php foreach ($mhs as $m): ?>
            <tr>
              <td><?= e($m["nim"]) ?></td>
              <td><?= e($m["nama"]) ?></td>
              <td><?= e($m["prodi"]) ?></td>
              <td><?= e($m["angkatan"]) ?></td>
              <td><?= e($m["email"]) ?></td>
              <td>
                <form method="post" onsubmit="return confirm('Hapus <?= e(addslashes($m["nama"])) ?>?')">
                  <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
                  <input type="hidden" name="aksi" value="hapus">
                  <input type="hidden" name="id" value="<?= $m["id"] ?>">
                  <button class="btn btn-danger" type="submit">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel">
      <h2>Tambah mahasiswa</h2>
      <form method="post" class="grid-form">
        <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
        <input type="hidden" name="aksi" value="tambah">
        <div><label for="nim">NIM</label><input id="nim" name="nim" required></div>
        <div><label for="nama">Nama lengkap</label><input id="nama" name="nama" required></div>
        <div>
          <label for="prodi_id">Program studi</label>
          <select id="prodi_id" name="prodi_id" required>
            <option value="">Pilih program studi</option>
            <?php foreach ($prodi as $p): ?>
              <option value="<?= $p["id"] ?>"><?= e($p["nama"]) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label for="angkatan">Angkatan</label><input id="angkatan" name="angkatan" type="number" min="2000" max="2100" value="<?= date("Y") ?>" required></div>
        <div><label for="email">Email</label><input id="email" name="email" type="email"></div>
        <div class="end"><button class="btn btn-primary" type="submit">Simpan mahasiswa</button></div>
      </form>
    </section>
  </main>
</body>
</html>
